# Tailwind - Team Profiles rotation with Theme Toggle

A Pen created on CodePen.io. Original URL: [https://codepen.io/cbolson/pen/vYMrwvy](https://codepen.io/cbolson/pen/vYMrwvy).

Forked from my iiCodeThis project https://icodethis.com/code/2455